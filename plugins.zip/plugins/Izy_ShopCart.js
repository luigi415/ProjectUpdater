//============================================================================
// Izy_ShopCart.js
//----------------------------------------------------------------------------
// This script will add a cart to your shop.
//============================================================================

var Imported = Imported || {};
Imported.Izy_SC = true;
Imported.Izy_SC_name = "Izy's Shop Cart";
Imported.Izy_SC_desc = "This script will add a cart to your shop.";
Imported.Izy_SC_version = '1.00';
Imported.Izy_SC_author = 'Izyees Fariz';

var Izy_SC = Izy_SC || {};

/*:
 * @plugindesc v1.00 This script will add a cart to your shop.
 * Izys library scripts.
 * @author Izyees Fariz
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 * This script will add a cart to your shop.
 * Free for commercial and non-Commercial games.
 * Credit me as Izyees Fariz.
 *
 * ============================================================================
 * Plugin Commands
 * ============================================================================
 * Plugin Command (incasesensitive):
 * ------------------------------------------------------------------
 *   start_shopping
 *
 *   Important! Use this to start the cart system.
 *
 * ------------------------------------------------------------------
 *   add_cart type x y
 *
 *   type is item, weapon, armor.
 *   x is the item id.
 *   y is the total amount.
 *
 * Example :
 *
 *   add_cart item 1
 *   - this will add 1 item 1 to cart.
 *   add_cart Weapon 3 4
 *   - this will add 4 weapon 3 to cart.
 * ------------------------------------------------------------------
 *   remove_cart type x y
 *
 *   type is item, weapon, armor.
 *   x is the item id.
 *   y is the total amount.
 *
 * Example :
 *
 *   remove_cart ARMOR 1
 *   - this will remove 1 armor 1 from cart.
 *   remove_cart Item 3 4
 *   - this will remove 3 item 4 from cart.
 * ------------------------------------------------------------------
 *   empty_cart type x
 *
 *   type is item, weapon, armor.
 *   x is the item id. set 'all' to empty cart.
 *
 * Example :
 *
 *   empty_cart item All
 *   - this will empty all items in the cart.
 *   empty_cart armor 1
 *   - this will completely remove armor 1 from cart.
 * ------------------------------------------------------------------
 *   pay_cart
 *
 *   empty cart and return to item also subtract money. End shopping.
 *
 * ------------------------------------------------------------------
 *   cart_taxes x
 *
 *   x is the taxes amount.
 *
 *   default is 0. set to negative for an offer.
 * Example :
 *   cart_taxes 3
 *   - set a 3% tax.
 *   cart_taxes -50
 *   - set a 50% offer.
 *
 * ============================================================================
 * Script
 * ============================================================================
 * Some script call that may help you.
 * Please dont forgot the () tag.
 *
 * ------------------------------------------------------------------
 * TAXES
 * ------------------------------------------------------------------
 *   $gameCart.setTaxes(x)
 *
 *   - set the taxes amount to x.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getTaxes()
 *
 *   - get the taxes amount.
 *
 * ------------------------------------------------------------------
 * ITEMS
 * ------------------------------------------------------------------
 *   $gameCart.getItemsCount()
 *
 *   - get how many items do you have in cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getItemsAmount(x)
 *
 *   - how many amount of the item's x you have in cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getItemsPrice()
 *
 *   - get price of all items.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getItemPrice(x)
 *
 *   - get the price of item x.
 *
 * ------------------------------------------------------------------
 * WEAPONS
 * ------------------------------------------------------------------
 *   $gameCart.getWeaponsCount()
 *
 *   - get how many weapons do you have in cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getWeaponsAmount(x)
 *
 *   - how many amount of the weapon's x you have in cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getWeaponsPrice()
 *
 *   - get price of all weapons.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getWeaponPrice(x)
 *
 *   - get the price of weapon x.
 *
 * ------------------------------------------------------------------
 * ARMORS
 * ------------------------------------------------------------------
 *   $gameCart.getArmorsCount()
 *
 *   - get how many armors do you have in cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getArmorsAmount(x)
 *
 *   - how many amount of the armor's x you have in cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getArmorsPrice()
 *
 *   - get price of all armors.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getArmorPrice(x)
 *
 *   - get the price of armor x.
 *
 * ------------------------------------------------------------------
 * PAYMENTS
 * ------------------------------------------------------------------
 *   $gameCart.getTotalPrice()
 *
 *   - get the price of all items, weapons and armors without tax.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getTotalPriceWithTaxes()
 *
 *   - get the price of all items, weapons and armors include tax.
 *
 * ------------------------------------------------------------------
 *   $gameCart.canPay()
 *
 *   - check if the party can pay or not.
 *
 * ------------------------------------------------------------------
 *   $gameCart.isShopping()
 *
 *   - check if still shopping.
 *
 * ------------------------------------------------------------------
 *   $gameCart.isNotPaying()
 *
 *   - check if the party is still not paying the goods on their cart
 *     if the party have more than 1 item in their cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.pauseShopping()
 *
 *   - pause the shopping process without emptying the cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.returnShopping()
 *
 *   - return to the shop after you pause it.
 *
 * ------------------------------------------------------------------
 *   $gameCart.isCartEmpty()
 *
 *   - check if the cart is empty.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getCartCount()
 *
 *   - return to the value of the items/weapons/armors types in the cart.
 *     you've bought.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getCartAmountCount()
 *
 *   - return to the value amount of the items/weapons/armors in the cart.
 *
 * ------------------------------------------------------------------
 *   $gameCart.getGoods()
 *
 *   - give items/weapons/armors without paying and end shopping.
 *
 * ------------------------------------------------------------------
 *
 * ============================================================================
 * Changelog
 * ============================================================================
 * Version 1.00:
 * - Finished Plugin!
 */

//============================================================================
// Startin' Script.
//============================================================================

(function () {
	function Game_Cart() {
		this.initialize.apply(this, arguments);
	}

	var dtamanager = DataManager.createGameObjects;
	DataManager.createGameObjects = function () {
		dtamanager.apply(this, arguments);
		$gameCart = new Game_Cart;
	};

	Game_Cart.prototype.initialize = function () {

		this.start = false;
		this.items = [];
		this.itemsAmount = [];
		this.itemsPrice = 0;
		this.weapons = [];
		this.weaponsAmount = [];
		this.weaponsPrice = 0;
		this.armors = [];
		this.armorsAmount = [];
		this.armorsPrice = 0;
		this.totalMoney = 0;
		this.taxes = 0;

		for (i = 0; i < $dataItems.length; i++) {
			this.items.push(false);
			this.itemsAmount.push(0);
		}
		for (i = 0; i < $dataWeapons.length; i++) {
			this.weapons.push(false);
			this.weaponsAmount.push(0);
		}
		for (i = 0; i < $dataArmors.length; i++) {
			this.armors.push(false);
			this.armorsAmount.push(0);
		}
	};

	Game_Cart.prototype.startCart = function () {
		this.clearCart();
		this.start = true;
	};

	Game_Cart.prototype.itemAdd = function (itemId, amount) {
		this.items[itemId] = true;
		if (amount) {
			this.itemsAmount[itemId] += amount;
		} else {
			this.itemsAmount[itemId] += 1;
		}
	};

	Game_Cart.prototype.setTaxes = function (amount) {
		this.taxes = amount;
	};

	Game_Cart.prototype.getTaxes = function () {
		return this.taxes;
	};

	Game_Cart.prototype.itemRemove = function (itemId, amount) {
		if (amount) {
			this.itemsAmount[itemId] -= amount;
		} else {
			this.itemsAmount[itemId] -= 1;
		}
		if (this.itemsAmount[itemId] <= 0) {
			this.items[itemId] = false;
			this.itemsAmount[itemId] = 0;
		}
	};

	Game_Cart.prototype.itemEmpty = function (itemId) {
		this.items[itemId] = false;
		this.itemsAmount[itemId] = 0;
	};

	Game_Cart.prototype.itemEmptyAll = function () {
		for (i = 0; i < this.items.length; i++) {
			this.itemEmpty(i)
		}
	};

	Game_Cart.prototype.getItemsCount = function () {
		this.itemsCount = 0;
		for (i = 0; i < this.items.length; i++) {
			if (this.items[i]) {
				this.itemsCount += 1;
			}
		}
		return this.itemsCount;
	};

	Game_Cart.prototype.getItemsAmount = function (itemId) {
		return this.itemsAmount[itemId];
	};

	Game_Cart.prototype.getItemsPrice = function () {
		this.countItemsPrice();
		return this.itemsPrice;
	};

	Game_Cart.prototype.countItemsPrice = function () {
		this.itemsPrice = 0;
		for (i = 0; i < this.items.length; i++) {
			if (this.items[i] == true) {
				this.temp_price = this.getItemPrice(i) * this.itemsAmount[i];
				this.itemsPrice += this.temp_price;
			}
		}
	};

	Game_Cart.prototype.getItemPrice = function (itemId) {
		return $dataItems[itemId].price;
	};

	Game_Cart.prototype.weaponAdd = function (weaponId, amount) {
		this.weapons[weaponId] = true;
		if (amount) {
			this.weaponsAmount[weaponId] += amount;
		} else {
			this.weaponsAmount[weaponId] += 1;
		}
	};

	Game_Cart.prototype.weaponRemove = function (weaponId, amount) {
		if (amount) {
			this.weaponsAmount[weaponId] -= amount;
		} else {
			this.weaponsAmount[weaponId] -= 1;
		}
		if (this.weaponsAmount[weaponId] <= 0) {
			this.weapons[weaponId] = false;
			this.weaponsAmount[weaponId] = 0;
		}
	};

	Game_Cart.prototype.weaponEmpty = function (weaponId) {
		this.weapons[weaponId] = false;
		this.weaponsAmount[weaponId] = 0;
	};

	Game_Cart.prototype.weaponEmptyAll = function () {
		for (i = 0; i < this.weapons.length; i++) {
			this.weaponEmpty(i);
		}
	};

	Game_Cart.prototype.getWeaponsCount = function () {
		this.weaponsCount = 0;
		for (i = 0; i < this.weapons.length; i++) {
			if (this.weapons[i]) {
				this.weaponsCount += 1;
			}
		}
		return this.weaponsCount;
	};

	Game_Cart.prototype.getWeaponsAmount = function (weaponId) {
		return this.weaponsAmount[weaponId];
	};

	Game_Cart.prototype.getWeaponsPrice = function () {
		this.countWeaponsPrice();
		return this.weaponsPrice;
	};

	Game_Cart.prototype.countWeaponsPrice = function () {
		this.weaponsPrice = 0;
		for (i = 0; i < this.weapons.length; i++) {
			if (this.weapons[i] == true) {
				this.temp_price = this.getWeaponPrice(i) * this.weaponsAmount[i];
				this.weaponsPrice += this.temp_price;
			}
		}
	};

	Game_Cart.prototype.getWeaponPrice = function (weaponId) {
		return $dataWeapons[weaponId].price;
	};

	Game_Cart.prototype.armorAdd = function (armorId, amount) {
		this.armors[armorId] = true;
		if (amount) {
			this.armorsAmount[armorId] += amount;
		} else {
			this.armorsAmount[armorId] += 1;
		}
	};

	Game_Cart.prototype.armorRemove = function (armorId, amount) {
		if (amount) {
			this.armorsAmount[armorId] -= amount;
		} else {
			this.armorsAmount[armorId] -= 1;
		}
		if (this.armorsAmount[armorId] <= 0) {
			this.armors[armorId] = false;
			this.armorsAmount[armorId] = 0;
		}
	};

	Game_Cart.prototype.armorEmpty = function (armorId) {
		this.armors[armorId] = false;
		this.armorsAmount[armorId] = 0;
	};

	Game_Cart.prototype.armorEmptyAll = function () {
		for (i = 0; i < this.armors.length; i++) {
			this.armorEmpty(i)
		}
	};

	Game_Cart.prototype.getArmorsCount = function () {
		this.armorsCount = 0;
		for (i = 0; i < this.armors.length; i++) {
			if (this.armors[i]) {
				this.armorsCount += 1;
			}
		}
		return this.armorsCount;
	};

	Game_Cart.prototype.getArmorsAmount = function (armorId) {
		return this.armorsAmount[armorId];
	};

	Game_Cart.prototype.getArmorsPrice = function () {
		this.countArmorsPrice();
		return this.armorsPrice;
	};

	Game_Cart.prototype.countArmorsPrice = function () {
		this.armorsPrice = 0;
		for (i = 0; i < this.armors.length; i++) {
			if (this.armors[i] == true) {
				this.temp_price = this.getArmorPrice(i) * this.armorsAmount[i];
				this.armorsPrice += this.temp_price;
			}
		}
	};

	Game_Cart.prototype.getArmorPrice = function (armorId) {
		return $dataArmors[armorId].price;
	};

	Game_Cart.prototype.countTotalPrice = function () {
		this.totalMoney = this.getItemsPrice() + this.getWeaponsPrice() + this.getArmorsPrice();
	};

	Game_Cart.prototype.getTotalPrice = function () {
		this.countTotalPrice();
		return this.totalMoney;
	};

	Game_Cart.prototype.getTotalPriceWithTaxes = function () {
		this.price_with_taxes = this.getTotalPrice() + ((this.getTaxes() / 100) * this.getTotalPrice())
			return Math.round(this.price_with_taxes);
	};

	Game_Cart.prototype.canPay = function () {
		if (this.getTotalPrice() > $gameParty.gold()) {
			return false;
		}
		return true;
	};

	Game_Cart.prototype.pay = function () {
		if (this.canPay()) {
			this.pay_gold = this.getTotalPrice() + ((this.getTaxes() / 100) * this.getTotalPrice());
			$gameParty.loseGold(Math.round(this.pay_gold));
			this.giveGoods();
			this.clearCart();
			this.start = false;
			return true;
		}
		return false;
	};

	Game_Cart.prototype.getGoods = function () {
		this.giveGoods();
		this.clearCart();
		this.start = false;
	};

	Game_Cart.prototype.giveGoods = function () {
		for (i = 0; i < this.items.length; i++) {
			if (this.items[i]) {
				$gameParty.gainItem($dataItems[i], this.itemsAmount[i]);
			}
		}
		for (i = 0; i < this.weapons.length; i++) {
			if (this.weapons[i]) {
				$gameParty.gainItem($dataWeapons[i], this.weaponsAmount[i]);
			}
		}
		for (i = 0; i < this.armors.length; i++) {
			if (this.weapons[i]) {
				$gameParty.gainItem($dataWeapons[i], this.weaponsAmount[i]);
			}
		}
	};

	Game_Cart.prototype.getCartCount = function () {
		return this.getItemsCount() + this.getWeaponsCount() + this.getArmorsCount();
	};
	
	Game_Cart.prototype.getCartAmountCount = function () {
		return this.getItemsAmountCount() + this.getWeaponsAmountCount() + this.getArmorsAmountCount();
	};
	
	Game_Cart.prototype.getItemsAmountCount = function () {
		this.itemsCount = 0;
		for (i = 0; i < this.items.length; i++) {
			if (this.items[i]) {
				this.itemsCount += this.itemsAmount[i];
			}
		}
		return this.itemsCount;
	};
	
	Game_Cart.prototype.getWeaponsAmountCount = function () {
		this.weaponsCount = 0;
		for (i = 0; i < this.weapons.length; i++) {
			if (this.weapons[i]) {
				this.itemsCount += this.weaponsAmount[i];
			}
		}
		return this.weaponsCount;
	};
	
	Game_Cart.prototype.getArmorsAmountCount = function () {
		this.armorsCount = 0;
		for (i = 0; i < this.armors.length; i++) {
			if (this.armors[i]) {
				this.armorsCount += this.armorsAmount[i];
			}
		}
		return this.armorsCount;
	};

	Game_Cart.prototype.isCartEmpty = function () {
		if (this.getCartCount() == 0) {
			return true;
		}
		return false;

	};

	Game_Cart.prototype.clearCart = function () {
		this.itemEmptyAll();
		this.weaponEmptyAll();
		this.armorEmptyAll();
	};

	Game_Cart.prototype.isShopping = function () {
		return this.start;
	};

	Game_Cart.prototype.pauseShopping = function () {
		this.pauseShopping = true;
		this.start = false;
	};

	Game_Cart.prototype.returnShopping = function () {
		if (this.pauseShopping) {
			this.pauseShopping = false;
			this.start = true;
		}
	};

	Game_Cart.prototype.isNotPaying = function () {
		this.curState = false;
		for (i = 0; i < this.items.length; i++) {
			if (this.items[i] == true) {
				this.curState = true;
			}
		}
		for (i = 0; i < this.weapons.length; i++) {
			if (this.weapons[i] == true) {
				this.curState = true;
			}
		}
		for (i = 0; i < this.armors.length; i++) {
			if (this.armors[i] == true) {
				this.curState = true;
			}
		}
		return this.curState;
	};

	//============================================================================
	// Plugin Commands
	//============================================================================

	Izy_SC.PLGC = Game_Interpreter.prototype.pluginCommand;
	Game_Interpreter.prototype.pluginCommand = function (command, args) {
		Izy_SC.PLGC.call(this, command, args)
		if (command.toLowerCase() == 'start_shopping') {
			$gameCart.startCart();
		}
		if (command.toLowerCase() == 'add_cart') {
			switch (args[0].toLowerCase()) {

			case "item":
				$gameCart.itemAdd(args[1], args[2]);
				break;

			case "weapon":
				$gameCart.weaponAdd(args[1], args[2]);
				break;

			case "armor":
				$gameCart.armorAdd(args[1], args[2]);
				break;

			}

		}
		if (command.toLowerCase() == 'remove_cart') {
			switch (args[0].toLowerCase()) {

			case "item":
				if (args[1].toLowerCase() == 'all') {
					$gameCart.itemEmptyAll();
				} else {
					if (args[2] && args[2].toLowerCase() == 'all') {
						$gameCart.itemEmpty(args[1]);
					} else {
						$gameCart.itemRemove(args[1], args[2]);
					}
				}
				break;

			case "weapon":
				if (args[1].toLowerCase() == 'all') {
					$gameCart.weaponEmptyAll();
				} else {
					if (args[2] && args[2].toLowerCase() == 'all') {
						$gameCart.weaponEmpty(args[1]);
					} else {
						$gameCart.weaponRemove(args[1], args[2]);
					}
				}
				break;

			case "armor":
				if (args[1].toLowerCase() == 'all') {
					$gameCart.armorEmptyAll();
				} else {
					if (args[2] && args[2].toLowerCase() == 'all') {
						$gameCart.armorEmpty(args[1])
					} else {
						$gameCart.armorRemove(args[1], args[2]);
					}
				}
				break;

			case "all":
				$gameCart.clearCart();
				break;

			}
		}
		if (command.toLowerCase() == 'empty_cart') {
			switch (args[0].toLowerCase()) {

			case "item":
				if (args[1].toLowerCase() == 'all') {
					$gameCart.itemEmptyAll();
				} else {
					$gameCart.itemEmpty(args[1]);
				}
				break;

			case "weapon":
				if (args[1].toLowerCase() == 'all') {
					$gameCart.weaponEmptyAll();
				} else {
					$gameCart.weaponEmpty(args[1]);
				}
				break;

			case "armor":
				if (args[1].toLowerCase() == 'all') {
					$gameCart.armorEmptyAll();
				} else {
					$gameCart.armorEmpty(args[1]);
				}
				break;

			case "all":
				$gameCart.clearCart();
				break;

			}
		}
		if (command.toLowerCase() == 'pay_cart') {
			$gameCart.pay();
		}
		if (command.toLowerCase() == 'cart_taxes') {
			$gameCart.setTaxes(args[0]);
		}
	};

})();

//============================================================================
// End Script.
//============================================================================
