// SOUL_PaytoSave.js

/*:
*
* @plugindesc Mimics the Pay to Save feature in Lunar 2: Eternal Blue.
* @author Soulpour777 - soulxregalia.wordpress.com
*
* @param Default Penalty
* @desc The default / first value of the penalty to save your game.
* @default 10
*
* @param Penalty Name
* @desc The word used to describe the pay to save mechanic when inside the save screen.
* @default Penalty

@help

Pay To Save Plugin
Author: Soulpour777

Plugin Commands:

To change the penalty of saving, use this plugin command:

PTS : Penalty : x

where x is the new value of the penalty before the player can save.

*
*/

var pTSave = PluginManager.parameters('SOUL_PayToSave');

var Imported = Imported || {};
Imported.PayToSave = true;

var Soulpour777 = Soulpour777 || {};
Soulpour777.PayToSave = Soulpour777.PayToSave || {};

Soulpour777.PayToSave.penaltySave = Number(pTSave['Default Penalty']);
Soulpour777.PayToSave.penaltyName = String(pTSave['Penalty Name']);

(function($){

	Soulpour777.PayToSave.Game_System_initialize = Game_System.prototype.initialize;
	Game_System.prototype.initialize = function() {
		Soulpour777.PayToSave.Game_System_initialize.call(this);
		this._penaltySave = Soulpour777.PayToSave.penaltySave;
	}

	Soulpour777.PayToSave.Scene_Save_onSavefileOk = Scene_Save.prototype.onSavefileOk;
	Scene_Save.prototype.onSavefileOk = function() {
	    if($gameParty.gold() >= $gameSystem._penaltySave) {
	    	$gameParty.loseGold($gameSystem._penaltySave);
	    	Soulpour777.PayToSave.Scene_Save_onSavefileOk.call(this);
	    } else {
	    	this.onSaveFailure();
	    }
	};

	Soulpour777.PayToSave.Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
	Game_Interpreter.prototype.pluginCommand = function(command, args) {
	    Soulpour777.PayToSave.Game_Interpreter_pluginCommand.call(this, command, args);
	    switch(command) {
	    	case 'PTS':
	    		if (args[0] === ':' && args[1] === 'Penalty' && args[2] === ':') {
	    			$gameSystem._penaltySave = Number(args[3]);
	    		} 
	    }
	};

	Scene_Save.prototype.helpWindowText = function() {
	    return TextManager.saveMessage + ' ' + Soulpour777.PayToSave.penaltyName + ':' + ' ' + String($gameSystem._penaltySave) + '\G';
	};

})();