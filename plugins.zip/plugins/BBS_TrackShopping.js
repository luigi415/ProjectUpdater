//=============================================================================
// Bluebooth Plugins - Track Shopping
// BBS_TrackShopping.js
//=============================================================================

//=============================================================================
 /*:
 * @title Track Shopping Plugin
 * @author Michael Morris (https://www.patreon.com/bluebooth)
 * @date Feb 13, 2016
 * @filename BBS_TrackShopping.js
 * If you enjoy my work, consider supporting me on Patreon!
 *
 * https://www.patreon.com/bluebooth
 *
 * @plugindesc v1.01 Tracks total money the player spends buying and selling at stores.
 * Special Thanks to Tsukihime for all the help.
 * Special Thanks to 'Ramza' Michael Sweeney for being so supportive.
 * 
 * ============================================================================
 * Terms of Use
 * ============================================================================
 *  - Free for use in non-commercial and commercial projects with credits
 * 
 * ============================================================================
 * Parameters
 * ============================================================================
 * @param Buying Tracking Game Variable
 * @desc Index of Game Variable to use to track amount bought.  Tracking does not reset when saving/loading.
 * @default -1
 * 
 * @param Selling Tracking Game Variable
 * @desc Index of Game Variable to use to track amount sold.  Tracking does not reset when saving/loading.
 * @default -1
 * 
 * @help
 * ============================================================================
 * Description
 * ============================================================================
 *
 * Tracks total money the player spends buying and selling at stores.
 *
 * ============================================================================
 * Change Log
 * ============================================================================
 * 1.01 - Plugin finished.
 * 
 */
//=============================================================================

//=============================================================================
var Imported = Imported || {} ;
var BBS = BBS || {};
Imported.TrackShopping = 1;
BBS.TrackShopping = BBS.TrackShopping || {};

(function() {

   	//=============================================================================
	// Parameter Variables
	//=============================================================================
	var parameters = PluginManager.parameters('BBS_TrackShopping');
	var pBuyGameVarIndex 		 = Number(parameters['Buying Tracking Game Variable'] || '-1');
	var pSellGameVarIndex	 	 = Number(parameters['Selling Tracking Game Variable'] || '-1');
	
	var BBS_TS_Scene_Shop_doBuy = Scene_Shop.prototype.doBuy;
	Scene_Shop.prototype.doBuy = function(number) {
        BBS_TS_Scene_Shop_doBuy.call(this, number);
				
		if (pBuyGameVarIndex > 0) {
			var changeInSpentGold = $gameVariables.value(pBuyGameVarIndex);
			changeInSpentGold = changeInSpentGold + (number * this.buyingPrice());
			$gameVariables.setValue(pBuyGameVarIndex, changeInSpentGold);
		}
	};
	
	var BBS_TS_Scene_Shop_doSell = Scene_Shop.prototype.doSell;
	Scene_Shop.prototype.doSell = function(number) {
        BBS_TS_Scene_Shop_doSell.call(this, number);
		
		if (pSellGameVarIndex > 0) {
			var changeInSoldGold = $gameVariables.value(pSellGameVarIndex);
			changeInSoldGold = changeInSoldGold + (number * this.sellingPrice());
			$gameVariables.setValue(pSellGameVarIndex, changeInSoldGold);
		}
	};

})(BBS.TrackShopping);
//=============================================================================
// End of File
//=============================================================================
